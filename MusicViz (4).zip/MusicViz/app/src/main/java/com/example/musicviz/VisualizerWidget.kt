package com.example.musicviz

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.RemoteViews

class VisualizerWidget : AppWidgetProvider() {
    companion object {
        private fun pi(c: Context, id: Int, a: String, k: Int) = PendingIntent.getForegroundService(c, id * 64 + k,
            Intent(c, VisualizerService::class.java).setAction(a).putExtra("id", id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        /** Нажатия и видимость зон. Кнопки — это службы (не activity), поэтому работают без разблокировки. */
        fun base(c: Context, id: Int, cfg: Cfg, compact: Boolean, qOpen: Boolean): RemoteViews {
            val rv = RemoteViews(c.packageName, R.layout.widget)
            val player = cfg.player == 1
            // Без плеера нажатие на виджет = старт/стоп; с плеером — открыть настройки этого виджета
            rv.setOnClickPendingIntent(R.id.root, if (player)
                PendingIntent.getActivity(c, id, Intent(c, MainActivity::class.java).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id), PendingIntent.FLAG_IMMUTABLE)
                else pi(c, id, "toggle", 0))
            val zones = listOf(R.id.z_prev to "prev", R.id.z_pp to "pp", R.id.z_next to "next", R.id.z_qb to "qt", R.id.z_info to "qt",
                R.id.c_prev to "prev", R.id.c_pp to "pp", R.id.c_next to "next", R.id.c_qb to "qt", R.id.c_info to "qt",
                R.id.qw0 to "r0", R.id.qw1 to "r1", R.id.qw2 to "r2", R.id.qw3 to "r3",
                R.id.qc0 to "r0", R.id.qc1 to "r1", R.id.qc2 to "r2", R.id.qc3 to "r3")
            zones.forEachIndexed { i, (v, a) -> rv.setOnClickPendingIntent(v, pi(c, id, a, 1 + i)) }
            fun vis(b: Boolean) = if (b) View.VISIBLE else View.GONE
            val any = cfg.ctrl == 1 || cfg.cover == 1
            rv.setViewVisibility(R.id.cWide, vis(player && !compact && any)); rv.setViewVisibility(R.id.cCompact, vis(player && compact && any))
            rv.setViewVisibility(R.id.qWide, vis(player && !compact && qOpen)); rv.setViewVisibility(R.id.qCompact, vis(player && compact && qOpen))
            val btn = if (cfg.ctrl == 1) View.VISIBLE else View.INVISIBLE
            for (v in listOf(R.id.z_prev, R.id.z_pp, R.id.z_next, R.id.z_qb, R.id.c_prev, R.id.c_pp, R.id.c_next, R.id.c_qb)) rv.setViewVisibility(v, btn)
            val info = if (cfg.cover == 1) View.VISIBLE else View.INVISIBLE
            rv.setViewVisibility(R.id.z_info, info); rv.setViewVisibility(R.id.c_info, info)
            return rv
        }
    }

    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            Cfg.initFor(c, id)
            val cfg = Cfg(c, id); val sz = Render.sizeOf(c, m, id)
            val rv = base(c, id, cfg, sz.compact, false)
            if (!VisualizerService.alive) { // пока сервис не запущен — «пустой» кадр, чтобы виджет был виден
                val buf = Buf(sz.w, sz.h)
                Render.render(buf, FloatArray(Render.BANDS), FloatArray(1024), cfg, Anim(), Ui(Track(), sz.compact, 0f))
                rv.setImageViewBitmap(R.id.img, buf.out)
            }
            m.updateAppWidget(id, rv)
        }
    }

    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, o: Bundle) { onUpdate(c, m, intArrayOf(id)) }

    override fun onDeleted(c: Context, ids: IntArray) { for (id in ids) Cfg.drop(c, id) }
}
