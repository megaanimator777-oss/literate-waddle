package com.example.musicviz

import android.app.*
import android.appwidget.AppWidgetManager
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.*
import android.media.audiofx.Visualizer
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.widget.RemoteViews
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread
import kotlin.math.*

/**
 * Два потока: аудио (анализ звука) и отрисовка (фиксированная частота кадров).
 * Плеер: следит за медиасессией любого приложения и выполняет команды с кнопок виджета / уведомления.
 */
class VisualizerService : Service() {
    private class WS(var cfg: Cfg) {
        val lv = FloatArray(Render.BANDS); val an = Anim()
        var buf: Buf? = null; var flat = false; var mx = 0f
        var qa = 0f; var uiVer = -1; var sig = 0; var layoutKey = ""
    }

    @Volatile private var viz: Visualizer? = null
    @Volatile private var mic: AudioRecord? = null
    @Volatile private var running = false
    @Volatile private var screenOn = true
    @Volatile private var state = 1 // 0 экран выключен, 1 музыка не играет, 2 играет
    @Volatile private var notifKey = -1
    private val mag = FloatArray(N / 2)
    private val wave = FloatArray(N)
    private var micFallback = false
    private var soundSeen = false
    private var lastSound = 0L
    private val cfg by lazy { Cfg(this, 0) }
    private val media by lazy { MediaWatch(this) }
    private val qOpen = ConcurrentHashMap<Int, Boolean>()
    private val screenRcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { screenOn = i.action == Intent.ACTION_SCREEN_ON }
    }

    companion object {
        const val N = 1024
        val FPS = intArrayOf(15, 24, 30, 40)
        @Volatile var alive = false
    }

    override fun onBind(i: Intent?): IBinder? = null

    private fun nAct(icon: Int, title: String, a: String, req: Int): Notification.Action {
        val pi = PendingIntent.getForegroundService(this, req, Intent(this, VisualizerService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = Notification.Action.Builder(Icon.createWithResource(this, icon), title, pi)
        if (Build.VERSION.SDK_INT >= 31) b.setAuthenticationRequired(false) // работает без разблокировки
        return b.build()
    }

    /** Уведомление с кнопками: видно и работает на экране блокировки. */
    private fun notif(t: Track): Notification {
        val b = Notification.Builder(this, "viz").setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
        if (cfg.lock == 1) {
            b.setContentTitle(if (t.ok && t.title.isNotEmpty()) t.title else "Визуализатор работает").setContentText(t.artist)
            t.cover?.let { b.setLargeIcon(it) }
            b.addAction(nAct(android.R.drawable.ic_media_previous, "Назад", "prev", 101))
            b.addAction(nAct(if (t.playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (t.playing) "Пауза" else "Играть", "pp", 102))
            b.addAction(nAct(android.R.drawable.ic_media_next, "Вперёд", "next", 103))
            b.addAction(nAct(android.R.drawable.ic_menu_close_clear_cancel, "Стоп", "toggle", 104))
            b.setStyle(Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2))
        } else b.setContentTitle("Визуализатор работает")
        return b.build()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val ch = NotificationChannel("viz", "Visualizer", NotificationManager.IMPORTANCE_LOW)
        ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        try {
            startForeground(1, notif(media.track), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) {
            Live.status = "Система не разрешила запуск (выдано ли разрешение на микрофон?): ${e.message}"
            stopSelf(); return START_NOT_STICKY
        }
        val a = i?.action; val wid = i?.getIntExtra("id", 0) ?: 0
        if (a == "toggle" && running) { stopSelf(); return START_NOT_STICKY }
        if (!running) {
            running = true; alive = true
            screenOn = getSystemService(PowerManager::class.java).isInteractive
            registerReceiver(screenRcv, IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_SCREEN_OFF)
            })
            thread { audioLoop() }
            thread { renderLoop() }
        }
        when (a) {
            "prev", "pp", "next" -> thread { media.act(a); Thread.sleep(200); media.poll() }
            "qt" -> qOpen[wid] = !(qOpen[wid] ?: false)
            "r0", "r1", "r2", "r3" -> { thread { media.act(a); Thread.sleep(200); media.poll() }; qOpen[wid] = false }
        }
        return START_STICKY
    }

    private fun openViz() {
        viz = Visualizer(0).also { it.setEnabled(false); it.setCaptureSize(N); it.setEnabled(true) }
        soundSeen = false; lastSound = System.currentTimeMillis()
    }

    private fun openMic() {
        mic = AudioRecord(MediaRecorder.AudioSource.MIC, 44100, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, N * 4).also { it.startRecording() }
    }

    private fun close() {
        try { viz?.release() } catch (_: Exception) { }
        viz = null
        try { mic?.stop(); mic?.release() } catch (_: Exception) { }
        mic = null
    }

    private fun audioLoop() {
        val am = getSystemService(AudioManager::class.java)
        val buf = ShortArray(N); val wb = ByteArray(N)
        val re = DoubleArray(N); val im = DoubleArray(N)
        var lastMode = -1; var statusAt = 0L
        while (running) {
            try {
                val now = System.currentTimeMillis()
                val mode = cfg.source
                if (mode != lastMode) { close(); micFallback = false; lastMode = mode }
                val useMic = mode == 2 || (mode == 0 && micFallback)
                // Экономия батареи: экран выключен или музыка не играет — ничего не слушаем
                if (!screenOn || !(useMic || am.isMusicActive)) {
                    close(); mag.fill(0f); wave.fill(0f)
                    state = if (screenOn) 1 else 0
                    Live.status = if (screenOn) "Музыка не играет — ожидание" else "Экран выключен — пауза"
                    Thread.sleep(300); continue
                }
                state = 2
                if (viz == null && mic == null) {
                    if (useMic) openMic() else try { openViz() } catch (e: Exception) {
                        if (mode == 0) { micFallback = true; continue } else throw e
                    }
                }
                val m = mic
                if (m != null) {
                    if (m.read(buf, 0, N) < N) { Thread.sleep(20); continue }
                    for (k in 0 until N) re[k] = buf[k] / 32768.0
                } else {
                    viz!!.getWaveForm(wb); Thread.sleep(25)
                    for (k in 0 until N) re[k] = ((wb[k].toInt() and 0xFF) - 128) / 128.0
                }
                var peak = 0.0
                for (k in 0 until N) {
                    wave[k] = re[k].toFloat(); peak = max(peak, abs(re[k]))
                    re[k] *= 0.5 - 0.5 * cos(2 * PI * k / (N - 1)); im[k] = 0.0
                }
                if (peak > 0.001) { lastSound = now; soundSeen = true }
                else if (viz != null && mode == 0 && !soundSeen && now - lastSound > 3000) { micFallback = true; close(); continue }
                fft(re, im)
                for (k in 0 until N / 2) mag[k] = (hypot(re[k], im[k]) / N * 4).toFloat()
                if (now - statusAt > 500) {
                    statusAt = now
                    val src = if (mic != null) (if (mode == 0) "микрофон (запасной)" else "микрофон") else "системный Visualizer"
                    Live.status = "Источник: $src · уровень %.3f".format(peak)
                }
            } catch (e: Exception) {
                Live.status = "Ошибка: ${e.javaClass.simpleName} ${e.message}"
                try { Thread.sleep(300) } catch (_: InterruptedException) { }
            }
        }
    }

    /** Полосы виджета из общего спектра + сглаживание по времени (быстро вверх, плавно вниз). */
    private fun step(s: WS, dt: Float) {
        val c = s.cfg; val gain = 10.0.pow((c.sens - 50) / 50.0)
        val ta = 20f + c.smooth * 0.6f; val td = 60f + c.smooth * 4f
        var sum = 0f; var mx = 0f
        for (b in 0 until Render.BANDS) {
            val t = Render.level(mag, b, c.range, gain)
            s.lv[b] += (t - s.lv[b]) * (1f - exp(-dt / (if (t > s.lv[b]) ta else td)))
            sum += s.lv[b]; mx = max(mx, s.lv[b])
        }
        s.an.step(dt, sum / Render.BANDS); s.mx = mx
    }

    private fun sigOf(c: Cfg) = listOf(c.mode, c.range, c.bars, c.glow, c.parts, c.alpha, c.bg, c.grad, c.colorA, c.colorB,
        c.player, c.cover, c.ctrl, c.glassViz, c.glassCard, c.glassCtrl).hashCode()

    private fun renderLoop() {
        val mgr = AppWidgetManager.getInstance(this)
        val cn = ComponentName(this, VisualizerWidget::class.java)
        val states = HashMap<Int, WS>(); val sizes = HashMap<Int, Sz>()
        val pvs = WS(Cfg(this, 0)); var pvSz = Sz(400, 300, false)
        var pvb = arrayOf(Buf(400, 300), Buf(400, 300))
        var pi = 0; var ids = IntArray(0); var idsAt = 0L; var pollAt = 0L
        var prev = System.nanoTime()
        while (running) {
            try {
                val t0 = System.nanoTime(); val ms = t0 / 1_000_000
                val dt = ((t0 - prev) / 1e6f).coerceIn(1f, 200f); prev = t0
                if (ms - idsAt > 1000) {
                    idsAt = ms; ids = mgr.getAppWidgetIds(cn)
                    for (id in ids) {
                        sizes[id] = Render.sizeOf(this, mgr, id)
                        states.getOrPut(id) { Cfg.initFor(this, id); WS(Cfg(this, id)) }
                    }
                    states.keys.retainAll(ids.toSet())
                }
                if (ms - pollAt > (if (screenOn) 500 else 3000)) { // плеер: трек, обложка, очередь; обновить уведомление
                    pollAt = ms; media.poll()
                    val nk = media.ver * 2 + cfg.lock
                    if (nk != notifKey) { notifKey = nk; getSystemService(NotificationManager::class.java).notify(1, notif(media.track)) }
                }
                val tr = media.track
                if (Live.watching) { // превью в приложении (настройки выбранного виджета)
                    val ps = sizes[Live.previewId] ?: Sz(400, 300, false)
                    if (ps.w != pvSz.w || ps.h != pvSz.h) { pvSz = ps; pvb = arrayOf(Buf(ps.w, ps.h), Buf(ps.w, ps.h)) }
                    if (pvs.cfg.id != Live.previewId) pvs.cfg = Cfg(this, Live.previewId)
                    step(pvs, dt); pi = pi xor 1
                    Render.render(pvb[pi], pvs.lv, wave, pvs.cfg, pvs.an, Ui(tr, pvSz.compact, 0f)); Live.bmp = pvb[pi].out
                }
                val st = state
                if (st == 0 || ids.isEmpty()) { Thread.sleep(if (Live.watching) 40 else 150); prev = System.nanoTime(); continue }
                var drew = false
                for (id in ids) {
                    val s = states[id] ?: continue; val sz = sizes[id] ?: Sz(360, 360, true)
                    val qo = qOpen[id] == true
                    val key = "${s.cfg.player}${s.cfg.cover}${s.cfg.ctrl}${sz.compact}$qo"
                    if (key != s.layoutKey) { s.layoutKey = key; mgr.partiallyUpdateAppWidget(id, VisualizerWidget.base(this, id, s.cfg, sz.compact, qo)) }
                    step(s, dt)
                    val qt = if (qo) 1f else 0f // анимация выезда очереди
                    val qn = s.qa + (qt - s.qa) * (1f - exp(-dt / 70f)); s.qa = if (abs(qt - qn) < .01f) qt else qn
                    val settled = st != 2 && s.mx < 0.01f
                    val sig = sigOf(s.cfg)
                    if (settled && s.flat && s.qa == qt && s.uiVer == media.ver && s.sig == sig) continue
                    if (settled) s.lv.fill(0f)
                    s.flat = settled; s.uiVer = media.ver; s.sig = sig; drew = true
                    var bf = s.buf
                    if (bf == null || bf.w != sz.w || bf.h != sz.h) { bf = Buf(sz.w, sz.h); s.buf = bf }
                    Render.render(bf, s.lv, wave, s.cfg, s.an, Ui(tr, sz.compact, s.qa))
                    val rv = RemoteViews(packageName, R.layout.widget)
                    rv.setImageViewBitmap(R.id.img, bf.out)
                    mgr.partiallyUpdateAppWidget(id, rv)
                }
                if (!drew) { Thread.sleep(if (Live.watching) 40 else 150); prev = System.nanoTime(); continue }
                val spent = (System.nanoTime() - t0) / 1_000_000
                Thread.sleep(max(1L, 1000L / FPS[cfg.fps.coerceIn(0, FPS.size - 1)] - spent))
            } catch (e: Exception) {
                Live.status = "Ошибка отрисовки: ${e.javaClass.simpleName} ${e.message}"
                try { Thread.sleep(300) } catch (_: InterruptedException) { }
            }
        }
    }

    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size; var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) { val t = re[i]; re[i] = re[j]; re[j] = t }
        }
        var len = 2
        while (len <= n) {
            val a = -2 * PI / len; val wr = cos(a); val wi = sin(a)
            var i = 0
            while (i < n) {
                var cr = 1.0; var ci = 0.0
                for (k in 0 until len / 2) {
                    val x = i + k; val y = x + len / 2
                    val tr = re[y] * cr - im[y] * ci; val ti = re[y] * ci + im[y] * cr
                    re[y] = re[x] - tr; im[y] = im[x] - ti; re[x] += tr; im[x] += ti
                    val t = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = t
                }
                i += len
            }
            len = len shl 1
        }
    }

    override fun onDestroy() {
        running = false; alive = false
        try { unregisterReceiver(screenRcv) } catch (_: Exception) { }
        close()
        Live.status = "Сервис не запущен"
        super.onDestroy()
    }
}
