package com.example.musicviz

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var img: ImageView
    private lateinit var st: TextView
    private var curId = -1
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { Live.bmp?.let { img.setImageBitmap(it) }; st.text = Live.status; h.postDelayed(this, 40) }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val wid = intent?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (wid != AppWidgetManager.INVALID_APPWIDGET_ID) { // лаунчер открыл настройки конкретного виджета
            Cfg.initFor(this, wid)
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid))
        }
        val g = Cfg(this, 0)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        img = ImageView(this).apply { setBackgroundColor(0xFF1A1A1A.toInt()) }
        l.addView(img, LinearLayout.LayoutParams(-1, 520))
        st = TextView(this).apply { textSize = 12f }
        l.addView(st)

        btn(l, "1. Разрешить микрофон и уведомления") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn(l, "2. Доступ к уведомлениям (обложка, название, кнопки)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        btn(l, "3. Отключить оптимизацию батареи") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        btn(l, "4. Запустить визуализацию") { startForegroundService(Intent(this, VisualizerService::class.java)) }
        btn(l, "Остановить") { stopService(Intent(this, VisualizerService::class.java)) }

        label(l, "Источник звука (для всех виджетов)")
        l.addView(spinner(listOf("Авто (Visualizer, при тишине — микрофон)", "Только Visualizer", "Только микрофон"), g.source) { g.source = it })
        label(l, "Частота кадров (ниже — если рывки или греется)")
        l.addView(spinner(VisualizerService.FPS.map { "$it кадров/с" }, g.fps) { g.fps = it })
        check(l, "Кнопки в уведомлении (видны и работают на экране блокировки)", g.lock == 1) { g.lock = if (it) 1 else 0 }

        // У каждого виджета свои настройки
        val mgr = AppWidgetManager.getInstance(this)
        val ids = mgr.getAppWidgetIds(ComponentName(this, VisualizerWidget::class.java))
        val names = listOf("Шаблон для новых виджетов") + ids.mapIndexed { i, id ->
            val o = mgr.getAppWidgetOptions(id)
            "Виджет ${i + 1} (${o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH)}×${o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT)} dp)"
        }
        val start = if (wid != AppWidgetManager.INVALID_APPWIDGET_ID && ids.contains(wid)) ids.indexOf(wid) + 1
            else if (ids.isNotEmpty()) 1 else 0
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        label(l, "Настройки для:")
        l.addView(spinner(names, start) { pos -> val nid = if (pos == 0) 0 else ids[pos - 1]; if (nid != curId) build(box, nid) })
        l.addView(box)
        build(box, if (start == 0) 0 else ids[start - 1])

        label(l, "Виджет: долгое нажатие на рабочем столе → Виджеты → Music Visualizer. Размер любой: растяните за рамку. Нажатие на виджет — старт/стоп.")
        setContentView(ScrollView(this).apply { addView(l) })
    }

    private fun build(box: LinearLayout, id: Int) {
        curId = id; Live.previewId = id; box.removeAllViews()
        val cfg = Cfg(this, id)
        label(box, "Плеер на виджете")
        check(box, "Показывать плеер (выключить — останется только визуализация)", cfg.player == 1) { cfg.player = if (it) 1 else 0 }
        check(box, "Обложка и название", cfg.cover == 1) { cfg.cover = if (it) 1 else 0 }
        check(box, "Кнопки: назад / пауза / вперёд / очередь", cfg.ctrl == 1) { cfg.ctrl = if (it) 1 else 0 }
        label(box, "Жидкое стекло (Liquid Glass) — включается отдельно")
        check(box, "На кнопках", cfg.glassCtrl == 1) { cfg.glassCtrl = if (it) 1 else 0 }
        check(box, "На обложке, названии и очереди", cfg.glassCard == 1) { cfg.glassCard = if (it) 1 else 0 }
        check(box, "На визуализации", cfg.glassViz == 1) { cfg.glassViz = if (it) 1 else 0 }
        label(box, "Режим")
        box.addView(spinner(Render.MODES, cfg.mode) { cfg.mode = it })
        label(box, "Частоты: бас / голос / высокие / всё вместе")
        box.addView(spinner(Render.RANGE_NAMES, cfg.range) { cfg.range = it })
        slider(box, "Чувствительность", 100, cfg.sens) { cfg.sens = it }
        slider(box, "Плавность (вправо — мягче)", 100, cfg.smooth) { cfg.smooth = it }
        slider(box, "Свечение", 100, cfg.glow) { cfg.glow = it }
        slider(box, "Частицы (плавающие огоньки)", 100, cfg.parts) { cfg.parts = it }
        slider(box, "Прозрачность визуализации", 95, 100 - cfg.alpha) { cfg.alpha = 100 - it }
        slider(box, "Затемнение фона (0 — совсем нет)", 100, cfg.bg) { cfg.bg = it }
        slider(box, "Количество полос", 88, cfg.bars - 8) { cfg.bars = it + 8 }
        colorRow(box, "Цвет 1", { cfg.colorA }, { cfg.colorA = it })
        box.addView(CheckBox(this).apply {
            text = "Градиент (второй цвет)"; isChecked = cfg.grad == 1
            setOnCheckedChangeListener { _, b -> cfg.grad = if (b) 1 else 0 }
        })
        colorRow(box, "Цвет 2", { cfg.colorB }, { cfg.colorB = it })
    }

    private fun label(l: LinearLayout, t: String) = l.addView(TextView(this).apply { text = t; textSize = 13f; setPadding(0, 24, 0, 0) })
    private fun btn(l: LinearLayout, t: String, a: () -> Unit) = l.addView(Button(this).apply { text = t; setOnClickListener { a() } })
    private fun check(l: LinearLayout, t: String, on: Boolean, cb: (Boolean) -> Unit) =
        l.addView(CheckBox(this).apply { text = t; isChecked = on; setOnCheckedChangeListener { _, b -> cb(b) } })
    private fun slider(l: LinearLayout, t: String, max: Int, cur: Int, on: (Int) -> Unit) { label(l, t); l.addView(seek(max, cur, on)) }

    private fun spinner(items: List<String>, sel: Int, on: (Int) -> Unit) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
        setSelection(sel)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { on(pos) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun seek(max: Int, start: Int, on: (Int) -> Unit) = SeekBar(this).apply {
        this.max = max; progress = start
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { on(v) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun colorRow(l: LinearLayout, title: String, get: () -> Int, set: (Int) -> Unit) {
        val hsv = FloatArray(3); Color.colorToHSV(get(), hsv)
        val sw = View(this)
        fun apply() { val c = Color.HSVToColor(hsv); sw.setBackgroundColor(c); set(c) }
        l.addView(TextView(this).apply { text = title; setPadding(0, 24, 0, 8) })
        l.addView(sw, LinearLayout.LayoutParams(-1, 56))
        l.addView(seek(359, hsv[0].toInt()) { hsv[0] = it.toFloat(); apply() })
        l.addView(seek(100, (hsv[1] * 100).toInt()) { hsv[1] = it / 100f; apply() })
        l.addView(seek(100, (hsv[2] * 100).toInt()) { hsv[2] = it / 100f; apply() })
        apply()
    }

    override fun onResume() { super.onResume(); Live.watching = true; h.post(tick) }
    override fun onPause() { super.onPause(); Live.watching = false; h.removeCallbacks(tick) }
}
