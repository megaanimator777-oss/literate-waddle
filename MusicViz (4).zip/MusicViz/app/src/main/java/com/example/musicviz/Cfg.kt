package com.example.musicviz

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import kotlin.reflect.KProperty

/** Общее состояние для превью в приложении и диагностики. */
object Live {
    @Volatile var bmp: Bitmap? = null
    @Volatile var status = "Сервис не запущен"
    @Volatile var watching = false
    @Volatile var previewId = 0
}

class IntPref(private val p: SharedPreferences, private val k: String, private val d: Int) {
    operator fun getValue(t: Any?, prop: KProperty<*>): Int = p.getInt(k, d)
    operator fun setValue(t: Any?, prop: KProperty<*>, v: Int) { p.edit().putInt(k, v).apply() }
}

/** Настройки. id = 0 — общие/шаблон для новых виджетов; id > 0 — отдельный виджет. */
class Cfg(c: Context, val id: Int = 0) {
    private val p = prefs(c)
    var source by IntPref(p, "0:src", 0)    // общие: 0 авто, 1 Visualizer, 2 микрофон
    var fps by IntPref(p, "0:fps", 2)       // общие: индекс в VisualizerService.FPS
    var lock by IntPref(p, "0:lock", 1)     // общие: кнопки в уведомлении (экран блокировки)
    var player by IntPref(p, "$id:player", 1) // плеер на виджете (0 — только визуализация)
    var cover by IntPref(p, "$id:cover", 1)   // обложка и название
    var ctrl by IntPref(p, "$id:ctrl", 1)     // кнопки управления
    var glassViz by IntPref(p, "$id:gv", 0)   // «жидкое стекло» на визуализации
    var glassCard by IntPref(p, "$id:gc", 1)  // ... на обложке, названии и очереди
    var glassCtrl by IntPref(p, "$id:gk", 1)  // ... на кнопках
    var mode by IntPref(p, "$id:mode", 0)
    var range by IntPref(p, "$id:range", 3) // 0 бас, 1 голос, 2 высокие, 3 всё
    var sens by IntPref(p, "$id:sens", 60)
    var smooth by IntPref(p, "$id:smooth", 60)
    var alpha by IntPref(p, "$id:alpha", 100) // непрозрачность, %
    var bg by IntPref(p, "$id:bg", 0)         // затемнение фона, %
    var bars by IntPref(p, "$id:bars", 32)    // 8..96
    var glow by IntPref(p, "$id:glow", 50)
    var parts by IntPref(p, "$id:parts", 0)   // частицы, %
    var grad by IntPref(p, "$id:g", 1)
    var colorA by IntPref(p, "$id:a", 0xFF00E5FF.toInt())
    var colorB by IntPref(p, "$id:b", 0xFFFF4081.toInt())

    companion object {
        fun prefs(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        private val KEYS = listOf("mode", "range", "sens", "smooth", "alpha", "bg", "bars", "glow", "parts", "g", "a", "b", "player", "cover", "ctrl", "gv", "gc", "gk")

        /** Новый виджет получает копию текущего шаблона и дальше настраивается отдельно. */
        fun initFor(c: Context, id: Int) {
            val p = prefs(c); if (p.contains("$id:init")) return
            val e = p.edit().putInt("$id:init", 1)
            for (k in KEYS) if (p.contains("0:$k")) e.putInt("$id:$k", p.getInt("0:$k", 0))
            e.apply()
        }

        fun drop(c: Context, id: Int) { val e = prefs(c).edit(); for (k in KEYS + "init") e.remove("$id:$k"); e.apply() }
    }
}
