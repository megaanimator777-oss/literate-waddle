package com.example.musicviz

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService

/** Пустой сервис: нужен только ради доступа к медиасессиям плееров («Доступ к уведомлениям»). */
class NotifListener : NotificationListenerService()

class QItem(val id: Long, val title: String, val sub: String, val icon: Bitmap?)

class Track(
    val title: String = "", val artist: String = "", val cover: Bitmap? = null, val playing: Boolean = false,
    val queue: List<QItem> = emptyList(), val ok: Boolean = false, val note: String = "Нажмите ▶ — запуск"
)

/** Следит за плеером (любое приложение): трек, обложка, очередь; отправляет команды. */
class MediaWatch(private val ctx: Context) {
    @Volatile var track = Track()
    @Volatile var ver = 0
    @Volatile private var ctl: MediaController? = null
    private var lastKey = ""

    private fun square(b: Bitmap?, px: Int): Bitmap? {
        if (b == null || b.isRecycled || b.width < 2 || b.height < 2) return null
        val s = minOf(b.width, b.height)
        return Bitmap.createScaledBitmap(Bitmap.createBitmap(b, (b.width - s) / 2, (b.height - s) / 2, s, s), px, px, true)
    }

    private fun set(t: Track, key: String) { if (key != lastKey) { lastKey = key; track = t; ver++ } }

    fun poll() {
        val list = try {
            ctx.getSystemService(MediaSessionManager::class.java).getActiveSessions(ComponentName(ctx, NotifListener::class.java))
        } catch (e: SecurityException) { null }
        if (list == null) { ctl = null; set(Track(note = "Включите доступ к уведомлениям"), "noaccess"); return }
        val c = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.firstOrNull()
        ctl = c
        if (c == null) { set(Track(note = "Включите музыку в любом плеере"), "none"); return }
        val md = c.metadata; val ps = c.playbackState
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val art = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val playing = ps?.state == PlaybackState.STATE_PLAYING
        val items = c.queue ?: emptyList()
        val active = ps?.activeQueueItemId ?: -1L
        val idx = items.indexOfFirst { it.queueId == active }
        val next = (if (idx >= 0) items.drop(idx + 1) else items).take(4)
        val key = "$title|$artist|$playing|${System.identityHashCode(art)}|${c.packageName}|" + next.joinToString(",") { it.queueId.toString() }
        if (key == lastKey) return
        val q = next.map {
            QItem(it.queueId, it.description.title?.toString() ?: "", it.description.subtitle?.toString() ?: "", square(it.description.iconBitmap, 64))
        }
        set(Track(title, artist, square(art, 160), playing, q, true), key)
    }

    /** prev / next / pp (пауза-воспроизведение) / r0..r3 (перейти к треку из очереди) */
    fun act(a: String) {
        if (ctl == null) poll()
        val c = ctl ?: return; val t = c.transportControls
        when {
            a == "prev" -> t.skipToPrevious()
            a == "next" -> t.skipToNext()
            a == "pp" -> if (track.playing) t.pause() else t.play()
            a.length == 2 && a[0] == 'r' -> track.queue.getOrNull(a[1] - '0')?.let { t.skipToQueueItem(it.id) }
        }
    }
}
