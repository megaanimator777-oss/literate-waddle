package com.example.musicviz

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.res.Configuration
import android.graphics.*
import android.text.TextPaint
import android.text.TextUtils
import kotlin.math.*

/** Анимационное состояние виджета: вращение (от энергии звука) и плавающие частицы. */
class Sz(val w: Int, val h: Int, val compact: Boolean)
class Ui(val t: Track, val compact: Boolean, val qa: Float)

class Anim {
    val n = 40
    var phase = 0f
    val x = FloatArray(n) { Math.random().toFloat() }
    val y = FloatArray(n) { Math.random().toFloat() }
    val s = FloatArray(n) { .3f + Math.random().toFloat() * .7f }
    val ph = FloatArray(n) { Math.random().toFloat() * 6.28f }
    fun step(dt: Float, energy: Float) {
        phase += dt * (.0003f + energy * .0022f)
        for (i in 0 until n) {
            y[i] -= dt * .00004f * (.4f + s[i]); x[i] += sin(ph[i] + phase * 2) * dt * .00003f
            if (y[i] < -.05f) { y[i] = 1.05f; x[i] = Math.random().toFloat() }
        }
    }
}

/** Буферы кадра (повторно используются, чтобы не мусорить памятью). */
class Buf(val w: Int, val h: Int) {
    val out: Bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val layer: Bitmap by lazy { Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888) }
    val s1: Bitmap by lazy { Bitmap.createBitmap(max(4, w / 2), max(4, h / 2), Bitmap.Config.ARGB_8888) }
    val layer2: Bitmap by lazy { Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888) }
    val s2: Bitmap by lazy { Bitmap.createBitmap(max(4, w / 6), max(4, h / 6), Bitmap.Config.ARGB_8888) }
}

object Render {
    const val BANDS = 96
    private const val BIN = 44100.0 / 1024
    val MODES = listOf("Столбики", "Зеркальные столбики", "Волна", "Круг", "LED-столбики", "Пульс", "Осциллограф",
        "Цветок", "Неон-линия", "Неон-кольцо", "Неон-треугольники")
    val RANGES = listOf(30.0 to 250.0, 200.0 to 4000.0, 3000.0 to 16000.0, 40.0 to 16000.0)
    val RANGE_NAMES = listOf("Бас", "Голос", "Высокие", "Всё вместе (бас + голос + высокие)")

    /** Уровень полосы b (0..1) для выбранного диапазона частот. mag — амплитуды БПФ (512 значений). */
    fun level(mag: FloatArray, b: Int, range: Int, gain: Double): Float {
        val (f0, f1) = RANGES[range.coerceIn(0, RANGES.size - 1)]
        val r = f1 / f0
        val lo = f0 * r.pow(b / BANDS.toDouble()); val hi = f0 * r.pow((b + 1) / BANDS.toDouble())
        val fc = sqrt(lo * hi); val bl = lo / BIN; val bh = hi / BIN
        var m = 0.0
        if (bh - bl < 1.0) { // узкая полоса — интерполируем между соседними бинами
            val pos = fc / BIN; val i = pos.toInt().coerceIn(1, mag.size - 2); val fr = (pos - i).coerceIn(0.0, 1.0)
            m = mag[i] * (1 - fr) + mag[i + 1] * fr
        } else for (k in max(1, bl.toInt())..min(mag.size - 1, bh.toInt())) m = max(m, mag[k].toDouble())
        m *= max(1.0, fc / 300).pow(.5) // подъём верхов, чтобы спектр выглядел ровнее
        return ((20 * log10(m * gain + 1e-6) + 70) / 60).toFloat().coerceIn(0f, 1f)
    }

    /** Размер картинки под реальный размер виджета + «компактный» режим (узкий виджет: два ряда). */
    fun sizeOf(c: Context, m: AppWidgetManager, id: Int): Sz {
        val o = m.getAppWidgetOptions(id); val d = c.resources.displayMetrics.density
        val land = c.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val wDp = if (land) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH) else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH)
        val hDp = if (land) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT) else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT)
        var w = (wDp * d).toInt(); var h = (hDp * d).toInt()
        if (w < 40 || h < 40) { w = 360; h = 360 }
        val k = min(1f, 480f / max(w, h))
        return Sz(max(32, (w * k).toInt()), max(32, (h * k).toInt()), wDp < 200)
    }

    private val fp = Paint(Paint.FILTER_BITMAP_FLAG)

    /** Кадр: фон → визуализация (+стекло, +свечение) → плеер (обложка, название, кнопки, очередь). */
    fun render(b: Buf, lv: FloatArray, wave: FloatArray, cfg: Cfg, an: Anim, ui: Ui?) {
        val co = Canvas(b.out)
        co.drawColor(Color.argb(cfg.bg * 255 / 100, 0, 0, 0), PorterDuff.Mode.SRC)
        if (cfg.glow == 0 && cfg.glassViz == 0) draw(co, b.w, b.h, lv, wave, cfg, an)
        else {
            b.layer.eraseColor(0); draw(Canvas(b.layer), b.w, b.h, lv, wave, cfg, an)
            val top = if (cfg.glassViz == 1) glassify(b) else b.layer
            if (cfg.glow > 0) {
                b.s1.eraseColor(0); Canvas(b.s1).drawBitmap(top, null, Rect(0, 0, b.s1.width, b.s1.height), fp)
                b.s2.eraseColor(0); Canvas(b.s2).drawBitmap(b.s1, null, Rect(0, 0, b.s2.width, b.s2.height), fp)
                val dst = Rect(0, 0, b.w, b.h)
                co.drawBitmap(b.s1, null, dst, Paint(fp).apply { alpha = min(255, cfg.glow * 255 / 120) })
                val g2 = Paint(fp).apply { alpha = min(255, cfg.glow * 255 / 50) }
                co.drawBitmap(b.s2, null, dst, g2)
                if (cfg.glow > 60) co.drawBitmap(b.s2, null, dst, g2)
            }
            co.drawBitmap(top, 0f, 0f, null)
        }
        if (ui != null && cfg.player == 1) drawUi(co, cfg, b.w.toFloat(), b.h.toFloat(), ui)
    }

    // ---------- «Жидкое стекло» (имитация Liquid Glass: реальное размытие обоев в виджете недоступно) ----------
    private fun wh(a: Int) = Color.argb(a, 255, 255, 255)
    private fun bk(a: Int) = Color.argb(a, 0, 0, 0)
    private fun fit(t: String, p: TextPaint, w: Float) = TextUtils.ellipsize(t, p, max(1f, w), TextUtils.TruncateAt.END).toString()

    private fun glassify(b: Buf): Bitmap {
        val l2 = b.layer2; l2.eraseColor(0); val c2 = Canvas(l2)
        val white = Paint().apply { colorFilter = PorterDuffColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN); alpha = 150 }
        c2.drawBitmap(b.layer, -2f, -2f, white)                      // световая кромка сверху-слева
        c2.drawBitmap(b.layer, 0f, 0f, Paint().apply { alpha = 190 }) // полупрозрачное тело
        val gl = Paint().apply {
            shader = LinearGradient(0f, 0f, 0f, b.h.toFloat(), wh(110), wh(12), Shader.TileMode.CLAMP)
            xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP)
        }
        c2.drawRect(0f, 0f, b.w.toFloat(), b.h.toFloat(), gl)        // глянцевый блик только по фигурам
        return l2
    }

    private fun glass(c: Canvas, r: RectF, rad: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(r.left, r.top, r.right, r.bottom, wh(70), wh(22), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, rad, rad, p)                                   // молочная заливка
        p.shader = LinearGradient(0f, r.top, 0f, r.bottom, bk(0), bk(46), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, rad, rad, p)                                   // тень внизу внутри
        c.save(); c.clipRect(r.left, r.top, r.right, r.centerY())
        p.shader = LinearGradient(0f, r.top, 0f, r.centerY(), wh(60), wh(0), Shader.TileMode.CLAMP)
        c.drawRoundRect(RectF(r.left + 2, r.top + 2, r.right - 2, r.bottom - 2), max(1f, rad - 2), max(1f, rad - 2), p) // блик
        c.restore()
        p.shader = LinearGradient(r.left, r.top, r.right, r.bottom, intArrayOf(wh(230), wh(24), wh(24), wh(170)),
            floatArrayOf(0f, .35f, .65f, 1f), Shader.TileMode.CLAMP)
        p.style = Paint.Style.STROKE; p.strokeWidth = max(1.5f, rad * .07f)
        c.drawRoundRect(r, rad, rad, p)                                   // зеркальный ободок
    }

    // ---------- Плеер ----------
    private fun tri(c: Canvas, ax: Float, cy: Float, bx: Float, hh: Float, p: Paint) {
        val path = Path(); path.moveTo(ax, cy); path.lineTo(bx, cy - hh); path.lineTo(bx, cy + hh); path.close(); c.drawPath(path, p)
    }

    /** k: 0 назад, 1 играть, 2 пауза, 3 вперёд, 4 стрелка очереди (поворачивается при открытии) */
    private fun icon(c: Canvas, k: Int, cx: Float, cy: Float, s: Float, qa: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; setShadowLayer(s * .15f, 0f, s * .06f, bk(100)) }
        val hh = s * .42f
        when (k) {
            0 -> { tri(c, cx - s * .5f, cy, cx - s * .05f, hh, p); tri(c, cx - s * .05f, cy, cx + s * .4f, hh, p) }
            1 -> tri(c, cx + s * .42f, cy, cx - s * .32f, s * .5f, p)
            2 -> {
                c.drawRoundRect(cx - s * .32f, cy - s * .45f, cx - s * .08f, cy + s * .45f, 3f, 3f, p)
                c.drawRoundRect(cx + s * .08f, cy - s * .45f, cx + s * .32f, cy + s * .45f, 3f, 3f, p)
            }
            3 -> { tri(c, cx + s * .5f, cy, cx + s * .05f, hh, p); tri(c, cx + s * .05f, cy, cx - s * .4f, hh, p) }
            else -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = s * .16f; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
                c.save(); c.rotate(180f * qa, cx, cy)
                val path = Path(); path.moveTo(cx - s * .45f, cy + s * .2f); path.lineTo(cx, cy - s * .25f); path.lineTo(cx + s * .45f, cy + s * .2f)
                c.drawPath(path, p); c.restore()
            }
        }
    }

    private fun button(c: Canvas, cfg: Cfg, k: Int, cx: Float, cy: Float, r: Float, qa: Float) {
        if (cfg.glassCtrl == 1) glass(c, RectF(cx - r, cy - r, cx + r, cy + r), r)
        icon(c, k, cx, cy, r * .9f, qa)
    }

    private fun cover(c: Canvas, cfg: Cfg, r: RectF, bmp: Bitmap?, letter: String = "♪") {
        val rad = r.width() * .22f
        c.save(); c.clipPath(Path().apply { addRoundRect(r, rad, rad, Path.Direction.CW) })
        if (bmp != null) c.drawBitmap(bmp, null, r, fp) else {
            c.drawRect(r, Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = LinearGradient(r.left, r.bottom, r.right, r.top, cfg.colorA, cfg.colorB, Shader.TileMode.CLAMP) })
            val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = r.height() * .55f }
            c.drawText(letter, r.centerX(), r.centerY() + r.height() * .19f, tp)
        }
        c.restore()
        if (cfg.glassCard == 1) c.drawRoundRect(r, rad, rad, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.5f; color = wh(120) })
    }

    private fun card(c: Canvas, cfg: Cfg, r: RectF, t: Track) {
        if (cfg.glassCard == 1) glass(c, r, r.height() * .28f)
        val pad = r.height() * .1f; var tx = r.left + pad * 1.6f
        if (cfg.cover == 1) {
            val cs = r.height() - pad * 2
            val cr = RectF(r.left + pad, r.top + pad, r.left + pad + cs, r.top + pad + cs)
            cover(c, cfg, cr, t.cover); tx = cr.right + pad
        }
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; typeface = Typeface.DEFAULT_BOLD; textSize = r.height() * .30f; setShadowLayer(3f, 0f, 1f, bk(110)) }
        val ap = TextPaint(tp).apply { typeface = Typeface.DEFAULT; textSize = r.height() * .24f; alpha = 200 }
        val maxW = r.right - pad - tx
        val title = if (t.ok) t.title.ifEmpty { "Ничего не играет" } else t.note
        val ty = if (t.ok && t.artist.isNotEmpty()) r.centerY() else r.centerY() + r.height() * .11f
        c.drawText(fit(title, tp, maxW), tx, ty, tp)
        if (t.ok && t.artist.isNotEmpty()) c.drawText(fit(t.artist, ap, maxW), tx, r.centerY() + r.height() * .27f, ap)
    }

    private fun queue(c: Canvas, cfg: Cfg, W: Float, H: Float, ui: Ui) {
        val rect = RectF(W * .02f, H * .04f, W * .98f, H * (if (ui.compact) .58f else .70f))
        c.saveLayerAlpha(0f, 0f, W, H, (255 * ui.qa).toInt().coerceIn(0, 255))
        c.translate(0f, (1f - ui.qa) * H * .08f)          // выезжает снизу вверх
        val rad = min(W, H) * .07f
        if (cfg.glassCard == 1) glass(c, rect, rad) else c.drawRoundRect(rect, rad, rad, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bk(130) })
        val rowH = rect.height() / 4
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; typeface = Typeface.DEFAULT_BOLD; textSize = rowH * .32f; setShadowLayer(3f, 0f, 1f, bk(110)) }
        val sp = TextPaint(tp).apply { typeface = Typeface.DEFAULT; textSize = rowH * .25f; alpha = 190 }
        val q = ui.t.queue
        if (q.isEmpty()) {
            tp.textAlign = Paint.Align.CENTER
            c.drawText(fit(if (ui.t.ok) "Очередь недоступна в этом плеере" else ui.t.note, tp, rect.width() * .9f), rect.centerX(), rect.centerY(), tp)
        } else for (i in q.indices) {
            val item = q[i]; val ry = rect.top + rowH * i
            val ic = RectF(rect.left + rowH * .15f, ry + rowH * .15f, rect.left + rowH * .85f, ry + rowH * .85f)
            cover(c, cfg, ic, item.icon, item.title.take(1).ifEmpty { "♪" })
            val x = ic.right + rowH * .2f; val mw = rect.right - x - rowH * .2f
            c.drawText(fit(item.title, tp, mw), x, ry + rowH * (if (item.sub.isEmpty()) .6f else .47f), tp)
            if (item.sub.isNotEmpty()) c.drawText(fit(item.sub, sp, mw), x, ry + rowH * .78f, sp)
        }
        c.restore()
    }

    // Геометрия должна совпадать с весами зон нажатий в res/layout/widget.xml
    private fun drawUi(c: Canvas, cfg: Cfg, W: Float, H: Float, ui: Ui) {
        val t = ui.t
        val kPlay = if (t.playing) 2 else 1
        if (ui.compact) {
            if (cfg.cover == 1) card(c, cfg, RectF(W * .02f, H * .61f, W * .98f, H * .795f), t)
            if (cfg.ctrl == 1) {
                val r = min(H * .085f, W * .1f); val cy = H * .90f
                button(c, cfg, 0, W * .125f, cy, r, ui.qa); button(c, cfg, kPlay, W * .375f, cy, r * 1.12f, ui.qa)
                button(c, cfg, 3, W * .625f, cy, r, ui.qa); button(c, cfg, 4, W * .875f, cy, r, ui.qa)
            }
        } else {
            if (cfg.cover == 1) card(c, cfg, RectF(W * .015f, H * .735f, W * .44f, H * .985f), t)
            if (cfg.ctrl == 1) {
                val r = min(H * .10f, W * .07f); val cy = H * .86f
                button(c, cfg, 0, W * .51f, cy, r, ui.qa); button(c, cfg, kPlay, W * .66f, cy, r * 1.12f, ui.qa)
                button(c, cfg, 3, W * .81f, cy, r, ui.qa); button(c, cfg, 4, W * .94f, cy, r, ui.qa)
            }
        }
        if (ui.qa > .01f) queue(c, cfg, W, H, ui)
    }

    private fun curve(xs: FloatArray, ys: FloatArray, closed: Boolean): Path {
        val n = xs.size; val p = Path()
        if (closed) {
            p.moveTo((xs[n - 1] + xs[0]) / 2, (ys[n - 1] + ys[0]) / 2)
            for (i in 0 until n) { val j = (i + 1) % n; p.quadTo(xs[i], ys[i], (xs[i] + xs[j]) / 2, (ys[i] + ys[j]) / 2) }
            p.close()
        } else {
            p.moveTo(xs[0], ys[0])
            for (i in 1 until n) p.quadTo(xs[i - 1], ys[i - 1], (xs[i - 1] + xs[i]) / 2, (ys[i - 1] + ys[i]) / 2)
            p.lineTo(xs[n - 1], ys[n - 1])
        }
        return p
    }

    private fun draw(c: Canvas, w: Int, h: Int, lv: FloatArray, wave: FloatArray, cfg: Cfg, an: Anim) {
        val a = cfg.colorA; val b = if (cfg.grad == 1) cfg.colorB else a
        val al = cfg.alpha * 255 / 100
        val W = w.toFloat(); val H = h.toFloat(); val m = min(W, H); val cx = W / 2; val cy = H / 2
        val sh = LinearGradient(0f, H, 0f, 0f, a, b, Shader.TileMode.CLAMP)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = sh; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; alpha = al }
        val n = cfg.bars.coerceIn(8, 96)
        fun v(i: Int, cnt: Int): Float {
            val s = i * lv.size / cnt; val e = min(lv.size, max(s + 1, (i + 1) * lv.size / cnt))
            var r = 0f; for (k in s until e) r = max(r, lv[k]); return r
        }
        fun avg(s: Int, e: Int): Float { var r = 0f; for (k in s until e) r += lv[k]; return r / (e - s) }

        val np = cfg.parts * an.n / 100
        if (np > 0) { // мягкие плавающие огоньки на фоне
            val pp = Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = sh }
            for (i in 0 until np) {
                val r = m * (.006f + .012f * an.s[i]); val pulse = .6f + .4f * sin(an.ph[i] + an.phase * 3)
                pp.alpha = (al * .12f).toInt(); c.drawCircle(an.x[i] * W, an.y[i] * H, r * 2.6f, pp)
                pp.alpha = (al * (.25f + .3f * pulse)).toInt(); c.drawCircle(an.x[i] * W, an.y[i] * H, r, pp)
            }
        }

        when (cfg.mode) {
            0 -> {
                val bw = W / n; val g = bw * .18f; val rr = min(bw / 2, 10f)
                for (i in 0 until n) c.drawRoundRect(i * bw + g, H - max(3f, v(i, n) * H), (i + 1) * bw - g, H, rr, rr, p)
            }
            1 -> {
                val bw = W / n; val g = bw * .18f; val rr = min(bw / 2, 10f)
                for (i in 0 until n) { val hh = max(2f, v(i, n) * H / 2); c.drawRoundRect(i * bw + g, cy - hh, (i + 1) * bw - g, cy + hh, rr, rr, p) }
            }
            2 -> {
                val xs = FloatArray(n) { (it + .5f) * W / n }; val ys = FloatArray(n) { H - max(3f, v(it, n) * H * .95f) }
                val path = curve(xs, ys, false)
                val fill = Path(path).apply { lineTo(xs[n - 1], H); lineTo(xs[0], H); close() }
                p.alpha = al * 35 / 100; c.drawPath(fill, p)
                p.alpha = al; p.style = Paint.Style.STROKE; p.strokeWidth = max(3f, m * .02f); c.drawPath(path, p)
            }
            3 -> {
                val r0 = m * .2f; val rl = m * .28f; val t = n * 2
                p.style = Paint.Style.STROKE; p.strokeWidth = max(2f, m * .022f * 24 / n)
                for (i in 0 until t) {
                    val k = if (i < n) i else t - 1 - i; val ang = i * 2 * PI / t - PI / 2; val r1 = r0 + max(3f, v(k, n) * rl)
                    c.drawLine(cx + (r0 * cos(ang)).toFloat(), cy + (r0 * sin(ang)).toFloat(),
                        cx + (r1 * cos(ang)).toFloat(), cy + (r1 * sin(ang)).toFloat(), p)
                }
            }
            4 -> {
                val rows = 12; val bw = W / n; val ch = H / rows; val g = max(1f, min(bw, ch) * .14f)
                for (i in 0 until n) {
                    val lit = (v(i, n) * rows + .5f).toInt()
                    for (r in 0 until lit) c.drawRoundRect(i * bw + g, H - (r + 1) * ch + g, (i + 1) * bw - g, H - r * ch - g, 2f, 2f, p)
                }
            }
            5 -> {
                val bass = avg(0, 12); val mid = avg(12, 56); val hi = avg(56, lv.size)
                p.style = Paint.Style.FILL; p.alpha = al * 6 / 10; c.drawCircle(cx, cy, m * (.08f + .12f * bass), p)
                p.style = Paint.Style.STROKE; p.alpha = al
                p.strokeWidth = m * (.01f + .035f * bass); c.drawCircle(cx, cy, m * (.2f + .06f * bass), p)
                p.strokeWidth = m * (.008f + .025f * mid); c.drawCircle(cx, cy, m * (.3f + .05f * mid), p)
                p.strokeWidth = m * (.006f + .02f * hi); c.drawCircle(cx, cy, m * (.4f + .04f * hi), p)
            }
            6 -> {
                val pts = min(w, 160); val gain = (10.0.pow((cfg.sens - 50) / 50.0) * 1.5).toFloat(); val path = Path()
                for (i in 0 until pts) {
                    val s = wave[i * (wave.size - 1) / (pts - 1)]
                    val y = cy - (s * gain).coerceIn(-1f, 1f) * H * .45f; val x = i * W / (pts - 1)
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                p.style = Paint.Style.STROKE; p.strokeWidth = max(3f, m * .02f); c.drawPath(path, p)
            }
            7 -> {
                val t = n * 2; val r0 = m * .16f; val rl = m * .3f
                val xs = FloatArray(t); val ys = FloatArray(t)
                for (i in 0 until t) {
                    val k = if (i < n) i else t - 1 - i; val ang = i * 2 * PI / t - PI / 2; val r = r0 + v(k, n) * rl
                    xs[i] = cx + (r * cos(ang)).toFloat(); ys[i] = cy + (r * sin(ang)).toFloat()
                }
                val path = curve(xs, ys, true)
                p.alpha = al * 35 / 100; c.drawPath(path, p)
                p.alpha = al; p.style = Paint.Style.STROKE; p.strokeWidth = max(3f, m * .018f); c.drawPath(path, p)
            }
            8 -> { // Неон-линия: пунктирные зеркальные столбики от центральной линии
                val bw = W / n; val seg = max(2f, m * .016f)
                p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.BUTT; p.strokeWidth = max(1.5f, bw * .55f)
                p.pathEffect = DashPathEffect(floatArrayOf(seg, seg * .7f), 0f)
                for (i in 0 until n) {
                    val x = (i + .5f) * bw; val half = max(seg * .5f, v(i, n) * H * .46f)
                    c.drawLine(x, cy, x, cy - half, p); c.drawLine(x, cy, x, cy + half, p)
                }
            }
            9 -> { // Неон-кольцо: кольцо со штриховыми всплесками (две доли, вращение)
                val R = m * .30f; val rl = m * .16f; val t = n * 4; val half = t / 2
                p.style = Paint.Style.STROKE; p.strokeWidth = max(2f, m * .012f); c.drawCircle(cx, cy, R, p)
                p.alpha = al * 25 / 100; p.strokeWidth = max(1f, m * .006f)
                c.drawCircle(cx, cy, R * .8f, p); c.drawCircle(cx, cy, R * .62f, p)
                p.alpha = al; p.strokeWidth = max(1.2f, m * .005f * 32 / n)
                val xs = FloatArray(t); val ys = FloatArray(t)
                for (j in 0 until t) {
                    val kk = j % half; val k = if (kk < half / 2) kk else half - 1 - kk
                    val ang = j * 2 * PI / t - PI / 2 + an.phase; val len = v(k, n) * rl
                    val ca = cos(ang); val sa = sin(ang)
                    xs[j] = cx + ((R + len) * ca).toFloat(); ys[j] = cy + ((R + len) * sa).toFloat()
                    c.drawLine(cx + (R * ca).toFloat(), cy + (R * sa).toFloat(), xs[j], ys[j], p)
                }
                p.strokeWidth = max(2f, m * .008f); c.drawPath(curve(xs, ys, true), p)
            }
            else -> { // Неон-треугольники: вложенные треугольники, грани «дышат» от звука, вращаются
                val pts = 28
                p.style = Paint.Style.STROKE; p.strokeWidth = max(2f, m * .011f)
                for (r in 0 until 4) {
                    val rad = m * (.44f - r * .085f); val rot = an.phase * (1f + r * .35f) * (if (r % 2 == 0) 1f else -1f)
                    val sg = if (r % 2 == 0) 1f else -1f
                    p.alpha = al * (100 - r * 12) / 100
                    val path = Path()
                    for (e in 0 until 3) {
                        val a0 = rot + e * 2 * PI / 3 - PI / 2; val a1 = rot + (e + 1) * 2 * PI / 3 - PI / 2
                        val x0 = (cx + rad * cos(a0)).toFloat(); val y0 = (cy + rad * sin(a0)).toFloat()
                        val x1 = (cx + rad * cos(a1)).toFloat(); val y1 = (cy + rad * sin(a1)).toFloat()
                        val len = max(1f, hypot(x1 - x0, y1 - y0)); val nx = (y1 - y0) / len; val ny = -(x1 - x0) / len
                        for (j in 0..pts) {
                            val t = j / pts.toFloat()
                            val s = max(0f, lv[((j * BANDS / (pts + 1)) + e * 7 + r * 13) % BANDS] - .05f)
                            val d = sg * s * m * .09f * sin(PI.toFloat() * t)
                            val x = x0 + (x1 - x0) * t + nx * d; val y = y0 + (y1 - y0) * t + ny * d
                            if (e == 0 && j == 0) path.moveTo(x, y) else path.lineTo(x, y)
                        }
                    }
                    path.close(); c.drawPath(path, p)
                }
            }
        }
    }
}
